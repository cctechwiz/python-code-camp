********************

Title: RPG Floor Tiles 02
Date: January 15th, 2012
Author: Neyjour
Email: Neyjour@gmail.com
Website: http://neyjour.deviantart.com


********************

File List:

Floor Tiles 01 Neyjour.png
Floor Tiles 02 Neyjour.png
Floor Tiles 03 Neyjour.png
Floor Tiles 04 Neyjour.png
RPG Floor Tiles 02 Promo.jpg
RPG Floor Tiles 02 ReadMe.txt


********************


Useage/Restrictions:

* For non-commercial use only.
* Sharing/redistribution of this file is permitted as long as you do not alter the zip or its contents in any way.
* Mods intended for sharing/redistribution are permitted, but you must credit me and send me a link so I can see what you've done!
* Mods that are shared/redistributed must also state that they are for non-commercial use only.


********************


Credits:

Rock texture by brenbren - deviantART
White Rock Stock texture by brenbren - deviantART
Natural Grid by Ryder Hook (cut mod by Bogie) - Dundjinni forum


********************