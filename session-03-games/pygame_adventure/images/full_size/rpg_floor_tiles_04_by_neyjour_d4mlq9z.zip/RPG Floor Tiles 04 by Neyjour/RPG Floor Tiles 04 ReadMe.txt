********************

Title: RPG Floor Tiles 04
Date: January 16th, 2012
Author: Neyjour
Email: Neyjour@gmail.com
Website: http://neyjour.deviantart.com


********************

File List:

Single Floor Tile 01 Neyjour.png
Single Floor Tile 02 Neyjour.png
Single Floor Tile 03 Neyjour.png
Single Floor Tile 04 Neyjour.png
Single Floor Tile 05 Neyjour.png
Single Floor Tile 06 Neyjour.png
Single Floor Tile 07 Neyjour.png
Single Floor Tile 08 Neyjour.png
Floor Tiles 01 Neyjour.png
Floor Tiles 02 Neyjour.png
Floor Tiles 03 Neyjour.png
Floor Tiles 04 Neyjour.png
RPG Floor Tiles 04 Promo.jpg
RPG Floor Tiles 04 ReadMe.txt


********************


Useage/Restrictions:

* For non-commercial use only.
* Sharing/redistribution of this file is permitted as long as you do not alter the zip or its contents in any way.
* Mods intended for sharing/redistribution are permitted, but you must credit me and send me a link so I can see what you've done!
* Mods that are shared/redistributed must also state that they are for non-commercial use only.


********************


Credits:

MarbleGreen texture by CGTextures - CGTextures
SoilCracked texture by Jacobo Cort�s Ferreira - CGTextures
Natural Grid by Ryder Hook (cut mods by Bogie) - Dundjinni forum


********************