********************

Title: RPG Floor Tiles 03
Original Date: January 16th, 2012
Updated Date: February 24th, 2014
Author: Neyjour
Email: NeyjourRedux@gmail.com
Website: http://neyjour.deviantart.com


********************

File List:

Single Floor Tile 01 Neyjour.png
Single Floor Tile 02 Neyjour.png
Single Floor Tile 03 Neyjour.png
Single Floor Tile 04 Neyjour.png
Single Floor Tile 05 Neyjour.png
Single Floor Tile 06 Neyjour.png
Single Floor Tile 07 Neyjour.png
Single Floor Tile 08 Neyjour.png
Floor Tiles 01 Neyjour.png
Floor Tiles 02 Neyjour.png
Floor Tiles 03 Neyjour.png
Floor Tiles 04 Neyjour.png
RPG Floor Tiles 03 Promo.jpg
RPG Floor Tiles 03 ReadMe.txt


********************


Rules:

* For personal non-commercial use in any capacity that is NOT a resource.

* For commercial use in maps and illustrations/photomanips ONLY.  For use in any other commercial capacity, please contact me via email.

* Sharing/redistribution of this zip file and its contents is NOT permitted.  Please direct others to my deviantART gallery if they would like to download it.

* Sharing/redistribution as new resources (stock-from-stock, modifications, etc.) is NOT permitted, either personally OR commercially.

* Credit and notification of use is not required, but would be much appreciated.


********************


Credits:

Rock texture 2 by ko--design - deviantART
Natural Grid by Ryder Hook (cut mods by Bogie) - Dundjinni forum


********************